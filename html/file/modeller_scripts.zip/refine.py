"""Functions to refine a selection to varying degrees. These functions are
   usually used by setting the md_level member of an automodel or loop model
   object."""


def consttemp(atmsel, actions, edat):
    """constant temperature MD"""
    MDtemp=300.0
    tmstep=3.0
    nmov=2000 #number of movies
    incequil=200
    incmov=1000 #number of timesteps = nmov*incmov
    #cap_atom_shift is 3 std dev above average avg max atomic move step, and will change as a function of MDtemp and tmstep
    cap_atom_shift=0.000101389*MDtemp+0.0525431
    write_intermediates = True
    if MDtemp > 300.0:
        EQtemp1=300.0+(MDtemp-300.0)/10.0
        EQtemp2=300.0+(MDtemp-300.0)/6.0
        EQtemp3=300.0+(MDtemp-300.0)/4.0
        EQtemp4=300.0+(MDtemp-300.0)/3.0
        EQtemp5=300.0+(MDtemp-300.0)/2.5
        EQtemp6=300.0+(MDtemp-300.0)/2.0
        EQtemp7=300.0+(MDtemp-300.0)/1.5
        EQtemp8=MDtemp
        EQtemp9=MDtemp
        EQtemp10=MDtemp
        EQits=50000
    else:
        EQtemp1=300.0
        EQtemp2=300.0
        EQtemp3=300.0
        EQtemp4=300.0
        EQtemp5=300.0
        EQtemp6=300.0
        EQtemp7=300.0
        EQtemp8=300.0
        EQtemp9=300.0
        EQtemp10=300.0
        EQits=50000

    refineCT(write_intermediates, edat, atmsel, actions, cap=cap_atom_shift, timestep=tmstep,
           equil_its=EQits, equil_equil=20,
           equil_temps=(EQtemp1, EQtemp2, EQtemp3, EQtemp4, EQtemp5, EQtemp6, EQtemp7, EQtemp8, EQtemp9, EQtemp10),
           sampl_its=incmov, sampl_equil=incequil,
           sampl_temp=MDtemp, sampl_nmov=nmov)

def very_fast(atmsel, actions, edat):
    """Very fast MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=4.0,
           equil_its=50, equil_equil=10,
           equil_temps=(150.0, 400.0, 1000.0),
           sampl_its=300, sampl_equil=100,
           sampl_temps=(1000.0, 800.0, 500.0, 300.0))


def fast(atmsel, actions, edat):
    """Fast MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=4.0,
           equil_its=100, equil_equil=20,
           equil_temps=(150.0, 250.0, 500.0, 1000.0),
           sampl_its=400, sampl_equil=100,
           sampl_temps=(1000.0, 800.0, 500.0, 300.0))


def slow(atmsel, actions, edat):
    """Slow MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=4.0,
           equil_its=200, equil_equil=20,
           equil_temps=(150.0, 250.0, 400.0, 700.0, 1000.0),
           sampl_its=600, sampl_equil=200,
           sampl_temps=(1000.0, 800.0, 600.0, 500.0, 400.0, 300.0))

def moderate(atmsel, actions, edat):
    """contant temperature annealing"""
    refine(atmsel, actions, cap=0.03, timestep=1.0,
           equil_its=300, equil_equil=20,
           equil_temps=(50.0, 150.0, 250.0, 300.0),
           sampl_its=1000, sampl_equil=200,
           sampl_temps=(400.0, 500.0, 300.0, 200.0, 50.0))

def none(atmsel, actions, edat):
    """NO MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=0.0001,
           equil_its=2, equil_equil=1,
           equil_temps=(0.01, 0.01),
           sampl_its=2, sampl_equil=1,
           sampl_temps=(0.01, 0.01))


def very_slow(atmsel, actions, edat):
    """Very slow MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=4.0,
           equil_its=300, equil_equil=20,
           equil_temps=(150.0, 250.0, 400.0, 700.0, 1000.0, 1300.0),
           sampl_its=1000, sampl_equil=200,
           sampl_temps=(1300.0, 1000.0, 800.0, 600.0, 500.0, 430.0, 370.0,
                        320.0, 300.0))


def slow_large(atmsel, actions, edat):
    """Very slow/large dt MD annealing"""
    refine(atmsel, actions, cap=0.39, timestep=10.0,
           equil_its=200, equil_equil=20,
           equil_temps=(150.0, 250.0, 400.0, 700.0, 1000.0, 1500.0),
           sampl_its=2000, sampl_equil=200,
           sampl_temps=(1500.0, 1000.0, 800.0, 600.0, 500.0, 400.0, 300.0))


def refine(atmsel, actions, cap, timestep, equil_its, equil_equil,
           equil_temps, sampl_its, sampl_equil, sampl_temps, **args):
    from modeller.optimizers import molecular_dynamics

    mdl = atmsel.get_model()
    md = molecular_dynamics(cap_atom_shift=cap, md_time_step=timestep,
                            md_return='FINAL', output=mdl.optimize_output,
                            actions=actions, **args)
    init_vel = True
    # First run for equilibration, the second for sampling:
    for (its, equil, temps) in ((equil_its, equil_equil, equil_temps),
                                (sampl_its, sampl_equil, sampl_temps)):
        for temp in temps:
            md.optimize(atmsel, max_iterations=its, equilibrate=equil,
                        temperature=temp, init_velocities=init_vel)
            init_vel=False


def refineCT(write_intermediates, edat, atmsel, actions, cap, timestep, equil_its, equil_equil,
             equil_temps, sampl_its, sampl_equil, sampl_temp, sampl_nmov, **args):
    from modeller.optimizers import molecular_dynamics
    
    mdl = atmsel.get_model()
    
    md = molecular_dynamics(cap_atom_shift=cap, md_time_step=timestep,
                            md_return='FINAL', output=mdl.optimize_output,
                            actions=actions, edat=edat, **args)
    init_vel = True
    # First run equilibration, reset velocities to equilibrate more quickly
    ctr=500
    for temp in equil_temps:
        md.optimize(atmsel, max_iterations=equil_its, equilibrate=equil_equil,
                    temperature=temp, init_velocities=init_vel, md_time_step=timestep)
        init_vel=False #turn off for randomized Dynamics
        if write_intermediates:
            ctr=ctr+1
            atmsel.get_model().write_int(ctr, 0001)


    init_vel=False #turn off for randomized Dynamics
    #begin sampling
    ctr=1000
    for i in range(sampl_nmov):
        md.optimize(atmsel, max_iterations=sampl_its, equilibrate=sampl_equil,
                    temperature=sampl_temp, init_velocities=init_vel, md_time_step=3.0)
        if write_intermediates:
            ctr=ctr+1
            atmsel.get_model().write_int(ctr, 0001)
