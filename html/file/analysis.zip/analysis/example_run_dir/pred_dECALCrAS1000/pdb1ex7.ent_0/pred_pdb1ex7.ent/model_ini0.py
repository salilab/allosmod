from modeller import *
from modeller.automodel import *
from modeller.scripts import complete_pdb

env = environ(rand_seed=-30434)
env.io.atom_files_directory = ['../atom_files']
env.libs.topology.read(file='$(LIB)/top_heav.lib')
env.libs.parameters.read(file='$(LIB)/par.lib')

# Read in HETATM records from template PDBs
env.io.hetatm = True

a = automodel(env, deviation=None, alnfile='align.ali',
knowns=('pdb1ex7.ent'), sequence='pm.pdb')
a.library_schedule = autosched.normal
a.md_level = refine.slow
a.repeat_optimization = 1
a.max_molpdf = 1e9

a.starting_model = 1
a.ending_model = 1
#a.auto_align()                      # get an automatic alignment
a.make()

# read model file and Assess all atoms with DOPE: 
#ctr=1
#for i in range(1):
#    mdl = complete_pdb(env, 'pm.pdb.B9999000%s.pdb' % ctr)
#    s = selection(mdl)
#    outff='000' + str(ctr) + '.profile'
#    s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file=outff,
#                  normalize_profile=True, smoothing_window=15)
#    ctr=ctr+1
