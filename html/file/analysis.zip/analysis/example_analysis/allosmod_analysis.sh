#!/bin/bash

analysis_dir=/netapp/sali/pweinkam/model/users/analysis/
if test -z $analysis_dir; then echo "set analysis_dir variable in allosmod_analysis.sh"; exit; fi

${analysis_dir}/bin/get_e.sh
${analysis_dir}/bin/get_p.sh
${analysis_dir}/bin/get_velocities.sh $analysis_dir
${analysis_dir}/bin/get_qi.sh $analysis_dir

${analysis_dir}/bin/check_runs.sh >check_runs.out
cat check_runs.out

